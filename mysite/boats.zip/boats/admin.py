from django.contrib import admin
from boats.models import Boat, Type

# Register your models here.
admin.site.register(Boat)
admin.site.register(Type)