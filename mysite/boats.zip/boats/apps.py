from django.apps import AppConfig


class BoatsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'boats'
